#version 330

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:sample_lightmap.glsl>
#else
#moj_import <minecraft:globals.glsl>
#moj_import <minecraft:reimagined.glsl>
#endif

#moj_import <minecraft:dynamictransforms.glsl>
#moj_import <minecraft:projection.glsl>

in vec3 Position;
in vec4 Color;
in vec2 UV0;
#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
in ivec2 UV2;
#endif

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)
uniform sampler2D Sampler2;
out float sphericalVertexDistance;
out float cylindricalVertexDistance;
#else

uniform sampler2D Sampler0;
#endif

out vec4 vertexColor;
out vec2 texCoord0;

void main() {

#if !defined(IS_GUI) && !defined(IS_SEE_THROUGH)

    gl_Position = ProjMat * ModelViewMat * vec4(Position, 1.0);

    sphericalVertexDistance = fog_spherical_distance(Position);
    cylindricalVertexDistance = fog_cylindrical_distance(Position);

    vertexColor = Color * sample_lightmap(Sampler2, UV2);
    texCoord0 = UV0;


#else
    Data data = reimagined_text(ProjMat, GameTime, Sampler0, Position, UV0, Color);


    gl_Position = ProjMat * ModelViewMat * vec4(data.position, 1.0);
    
    vertexColor = data.color;
    texCoord0 = data.uv0;
#endif
}