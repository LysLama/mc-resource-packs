#version 330

#moj_import <minecraft:fog.glsl>
#moj_import <minecraft:dynamictransforms.glsl>

uniform sampler2D Sampler0;

in float sphericalVertexDistance;
in float cylindricalVertexDistance;
in vec2 texCoord0;
in vec4 OriginalColor;
in vec4 vertexColor;

out vec4 fragColor;

void main() {
    vec4 color = texture(Sampler0, texCoord0) ;

    ivec4 ich = ivec4(round(texelFetch(Sampler0, ivec2(texCoord0 * textureSize(Sampler0, 0)), 0) * 255));

    switch (ich.a) {
        case 254:
        case 200: break;
        case 250:
        case 252: 
        case 253: color *= vec4(OriginalColor.rgb,1); break;
        default: color *= vertexColor * ColorModulator; break;
    }

    if(round(texture(Sampler0, texCoord0).a*255) == 252.0){

    color = texture(Sampler0, texCoord0);

    }


    if (color.a < 0.1) {
        discard;
    }


    fragColor = apply_fog(color, sphericalVertexDistance, cylindricalVertexDistance, FogEnvironmentalStart, FogEnvironmentalEnd, FogRenderDistanceStart, FogRenderDistanceEnd, FogColor);
}